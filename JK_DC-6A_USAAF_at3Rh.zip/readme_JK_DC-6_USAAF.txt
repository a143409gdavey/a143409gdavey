This folder contains a repaint for the Douglas DC-6 by PMDG for MSFS2020, in the imaginary colors of DC-6A 45476 of the 25th TCS , USAAF, 1945
Repaint by JanKees Blom, based on the paintkit by PMDG.

INSTALLATION

1. Unzip to a temporary location.

2. Copy the "JK_DC-6_USAAF" folder in this download to your "Community" folder in MSFS2020.

3. Have fun flying!

ACKNOWLEDGEMENTS

The paintkit used for this repaint was supplied by PMDG. Thank you!

LEGAL STUFF

This repaint is released as FREEWARE.  You may use and modify it in any way you wish, but 
you may NOT use it in any kind of money-making endeavor, and you may NOT publicly 
distribute any copies of it, whether modified or not, without my permission. 

Jan Kees Blom

CONTACT

Questions and/or comments about this repaint are always welcome via e-mail at jkrepaints@gmail.com.  
10 July 2021